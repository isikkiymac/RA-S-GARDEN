import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

void main() => runApp(new MyApp1());

class MyApp1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(home:MyApp());
  }
}


class MyApp extends StatefulWidget{
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String girilenMetin = " ";




  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text("RA'S GARDEN"),
      ),
      body: ListView(
        children: [Padding(
          padding: const EdgeInsets.only(top:20.0, left:20, right:20),
          child: Image.network(
            "https://pbs.twimg.com/media/FAxcG3xXsAU-G3b?format=jpg&name=medium",
            fit: BoxFit.cover,
          ),
        ),Padding(
          padding: const EdgeInsets.only(top:20, left:100, right:100),
          child: RaisedButton(onPressed:(){
            Navigator.push(context, MaterialPageRoute(builder: (context) {
              return Stream ();
            }));
          }, color: Colors.black26,child:Text("Sign In/ Sign up"),),
        ),
          Padding(
            padding: const EdgeInsets.only(left: 20.0, right: 20, top: 50.0),
            child: TextField(
              keyboardType: TextInputType.text,
              autofocus: false,
              autocorrect: false,
              maxLines: 1,
              maxLengthEnforced: true,
              cursorColor: Colors.black26,
              decoration: InputDecoration(
                  hintText: "Email",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(1)),
                  ),
                  filled: true,
                  fillColor: Colors.black26),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 20.0, right: 20, top: 30.0),
            child: TextField(
              onSubmitted: (girilenDeger) {
                setState(() {
                  girilenMetin = girilenDeger;
                  debugPrint(girilenDeger);
                });
              },
              keyboardType: TextInputType.emailAddress,
              autofocus: false,
              autocorrect: false,
              maxLines: 1,
              maxLengthEnforced: true,
              cursorColor: Colors.black26,
              decoration: InputDecoration(
                  hintText: "Password",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(1)),
                  ),
                  filled: true,
                  fillColor: Colors.black26),
            ),
          ),
          Container(
            color: Colors.black12,
            width: double.infinity,
            height: 0,
            child: Align(
              child: Text(girilenMetin),
              alignment: Alignment.center,

            ),
          )
        ],
      ),
    );
  }
}

class Stream extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        drawer: Drawer(
          child: Column(
            children: [
              UserAccountsDrawerHeader(
                accountEmail: Text("Gmail Address"),
                accountName: Text("Name Surname"),
                currentAccountPicture: CircleAvatar(
                  backgroundImage: NetworkImage(
                      "https://solarsystem.nasa.gov/internal_resources/3577"),
                ),
              ),
              Expanded(
                child: ListView(
                  children: [
                    RaisedButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) {
                          return MySkins();
                        }));
                      },
                      color: Colors.black26,
                      child: Text("My Skins"),
                    ),
                    RaisedButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) {
                          return MyScores();
                        }));
                      },
                      color: Colors.black26,
                      child: Text("My Score"),
                    ),
                    RaisedButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) {
                          return GlobalRanking();
                        }));
                      },
                      color: Colors.black26,
                      child: Text("Global Ranking"),
                    ),
                    RaisedButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) {
                          return MyApp();
                        }));
                      },
                      color: Colors.black26,
                      child: Text("Log out"),
                    ),
                    AboutListTile(
                      applicationName: "Ra's Garden",
                      applicationIcon: Icon(Icons.animation),
                      applicationVersion: "2.0",
                      child: Text("About Us"),
                      applicationLegalese: null,
                      icon: Icon(Icons.arrow_right),
                      aboutBoxChildren: [Text("Made in Turkey"), Text("By the Team Secret of Dark")],
                    )
                  ],
                ),
              )
            ],
          ),
        ),
        appBar: AppBar(
          title: Text("RA'S GARDEN"),
        ),
        body: CustomScrollView(
          slivers: [
            SliverAppBar(
              expandedHeight: 200,
              pinned: true,
              floating: true,
              flexibleSpace: FlexibleSpaceBar(
                background: Image.network(
                  "https://pbs.twimg.com/media/FAxcG3xXsAU-G3b?format=jpg&name=medium",
                  fit: BoxFit.cover,
                ),
              ),
            ),
            SliverList(delegate: SliverChildListDelegate(ListOfSentences()))
          ],
        )
    );
  }

  List<Widget> ListOfSentences() {
    return [
      Container(
        height: 100,
        color: Colors.black12,
        child: Center(child: Text("Mercury")),
      ),
      Container(
        height: 100,
        color: Colors.black26,
        child: Center(child: Text("Venus")),
      ),
      Container(
        height: 100,
        color: Colors.black38,
        child: Center(child: Text("Earth")),
      ),
      Container(
        height: 100,
        color: Colors.black45,
        child: Center(child: Text("Earth's Moon")),
      ),
      Container(
        height: 100,
        color: Colors.black12,
        child: Center(child: Text("Mars")),
      ),
      Container(
        height: 100,
        color: Colors.black45,
        child: Center(child: Text("Jupiter")),
      ),
      Container(
        height: 100,
        color: Colors.black38,
        child: Center(child: Text("Saturn")),
      ),
      Container(
        height: 100,
        color: Colors.black26,
        child: Center(child: Text("Uranus")),
      ),
      Container(
        height: 100,
        color: Colors.black12,
        child: Center(child: Text("Neptune")),
      ),
    ];
  }
}



class GlobalRanking extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Global Ranking"),
      ),
      body: Column(
        children: [
          Card(
            child: ListTile(
              title: Text("Name Surname"),
              subtitle: Text("Total Score: 1390000"),
              leading: Icon(Icons.person),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("Name Surname"),
              subtitle: Text("Total Score: 1120000"),
              leading: Icon(Icons.person),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("Name Surname"),
              subtitle: Text("Total Score: 120000"),
              leading: Icon(Icons.person),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("Name Surname"),
              subtitle: Text("Total Score: 120000"),
              leading: Icon(Icons.person),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("Name Surname"),
              subtitle: Text("Total Score: 118000"),
              leading: Icon(Icons.person),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("Name Surname"),
              subtitle: Text("Total Score: 115000"),
              leading: Icon(Icons.person),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("Name Surname"),
              subtitle: Text("Total Score: 107000"),
              leading: Icon(Icons.person),
            ),
          ),
        ],
      ),
    );
  }
}


class MySkins extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("My Skins"),
      ),
      body: Column(
        children: [
          Card(
            child: ListTile(
              title: Text("#1"),
              subtitle: Text("Click here to view"),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("#8"),
              subtitle: Text("Click here to view"),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("#16"),
              subtitle: Text("Click here to view"),
            ),
          ),
          RaisedButton(
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return AddScore();
              }));
            },
            color: Colors.black12,
            child: Text("Add Skin"),
          ),
        ],
      ),
    );
  }
}

class MyScores extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("My Scores"),
      ),
      body: Column(
        children: [
          Card(
            child: ListTile(
              title: Text("Exploration in Mars"),
              subtitle: Text("3 mission completed. Score: 300"),
              leading: FlutterLogo(),
              trailing: Icon(Icons.more_vert),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("Exploration in Moon"),
              subtitle: Text("2 mission completed. Score: 200"),
              leading: FlutterLogo(),
              trailing: Icon(Icons.more_vert),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("Exploration in Jupiter"),
              subtitle: Text("1 mission completed. Score: 200"),
              leading: FlutterLogo(),
              trailing: Icon(Icons.more_vert),
            ),
          ),
        ],
      ),
    );
  }
}

class AddScore extends StatelessWidget {
  bool checkedValue = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Add Skin"),
      ),
      body: Container(
        color: Colors.white,
        height: 400,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                SizedBox(
                  width: 20,
                ),
                Text("Number of Skin:"),
                Container(width: 100, child: TextFormField())
              ],
            ),
            RaisedButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return SkinList();
                }));
              },
              color: Colors.black12,
              child: Text("List of the skins"),
            ),
          ],
        ),
      ),
    );
  }
}

class SkinList extends StatelessWidget {
  bool checkedValue = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("List of Skins"),
      ),
      body: Column(
        children: [
          Card(
            child: ListTile(
              title: Text("#1"),
              subtitle: Text("Score needed to buy: 100   Click here to view"),
              leading: FlutterLogo(),
              trailing: Icon(Icons.more_vert),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("#2"),
              subtitle: Text("Score needed to buy: 400   Click here to view"),
              leading: FlutterLogo(),
              trailing: Icon(Icons.more_vert),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("#3"),
              subtitle: Text("Score needed to buy: 500   Click here to view"),
              leading: FlutterLogo(),
              trailing: Icon(Icons.more_vert),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("#4"),
              subtitle: Text("Score needed to buy: 600   Click here to view"),
              leading: FlutterLogo(),
              trailing: Icon(Icons.more_vert),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("#5"),
              subtitle: Text("Score needed to buy: 70   Click here to view"),
              leading: FlutterLogo(),
              trailing: Icon(Icons.more_vert),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("#6"),
              subtitle: Text("Score needed to buy: 850   Click here to view"),
              leading: FlutterLogo(),
              trailing: Icon(Icons.more_vert),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("#7"),
              subtitle: Text("Score needed to buy: 900   Click here to view"),
              leading: FlutterLogo(),
              trailing: Icon(Icons.more_vert),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("#8"),
              subtitle: Text("Score needed to buy: 1300   Click here to view"),
              leading: FlutterLogo(),
              trailing: Icon(Icons.more_vert),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("#9"),
              subtitle: Text("Score needed to buy: 1500   Click here to view"),
              leading: FlutterLogo(),
              trailing: Icon(Icons.more_vert),
            ),
          ),
        ],
      ),
    );
  }
}