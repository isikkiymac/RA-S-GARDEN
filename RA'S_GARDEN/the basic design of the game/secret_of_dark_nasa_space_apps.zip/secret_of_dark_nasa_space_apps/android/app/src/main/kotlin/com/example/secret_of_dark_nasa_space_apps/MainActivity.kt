package com.example.secret_of_dark_nasa_space_apps

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
